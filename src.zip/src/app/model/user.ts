export class User {
    pan?:string;
    contactNumber:string;
    email:string;
    name:string;
    dob:string;
    password:string;
}
