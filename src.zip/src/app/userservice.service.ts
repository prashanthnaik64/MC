import { Injectable } from '@angular/core';
import { UserModel } from 'src/entity/UserModel';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Accounts } from 'src/entity/accounts';

type EntityResponseType = HttpResponse<UserModel[]>;
type EntityResponseType1 = HttpResponse<Accounts[]>;



@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
 

  constructor(private http:HttpClient) { }
  getUsers():Observable<EntityResponseType>{
    //return this.http.get<StudentModel[]>("http://localhost:8084/students", {observe: 'response'});
    return this.http.get<UserModel[]>("http://localhost:8080/customers", {observe: 'response'});
}
saveUser(userModel:UserModel){
  return this.http.post<UserModel>("http://localhost:8080/customer", userModel, {observe: 'response'});
}
getAccounts(pan):Observable<EntityResponseType1>{
  return this.http.get<Accounts[]>("http://localhost:8094/"+pan, {observe: 'response'});
}
saveAccounts(accounts:Accounts){
  return this.http.post<Accounts>("http://localhost:8094/account", accounts, {observe: 'response'});
}


}
