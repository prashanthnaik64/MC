import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserserviceService } from '../userservice.service';
import { FormGroup } from '@angular/forms';
import { Accounts } from 'src/entity/accounts';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {
  myForm2: FormGroup;
  pan:string;
  
  acc:Accounts[];
  constructor(private router:Router,private service:UserserviceService,private route: ActivatedRoute) { }
  //pan=this.route.snapshot.params['pan'];

  ngOnInit() {
    this.pan=this.route.snapshot.params['form.value.pan'];
    console.log(this.pan);
    this.service.getAccounts(this.pan).subscribe(data => {
      this.acc = data.body;
      console.log(data.body);

  },
  );

  }
  createAccount(){
    this.router.navigate(['/user']);
  }
  
  getbyuser(){
    //const p=this.pan;
    this.service.getAccounts(this.pan).subscribe(data => {
      this.acc = data.body;
      console.log(data.body);

  },
  );

  

}
ons(){
  this.router.navigate(['/']);
}
}
