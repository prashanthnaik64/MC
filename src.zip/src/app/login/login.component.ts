import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UserModel } from 'src/entity/UserModel';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  
  title = 'Angular Form Validation Tutorial';
  users:UserModel[];
  myForm2: FormGroup;
  submitted = false;
  msg="";
  pan:String;
  constructor(private router:Router,private service:UserserviceService) {}
   


  ngOnInit(): void {
    this.service.getUsers().subscribe(data => {
         this.users = data.body;
         console.log(data.body);
    });
    {
      this.myForm2=new FormGroup({
        pan:new FormControl('',Validators.required),
        password:new FormControl('',Validators.required)
      }
      );
    }
     
  }
  onSubmit(form:FormGroup){
    
  
    var k=0;
    
    for(var i=0;this.users.length;i++)
    {
      if(this.users[i].pan==form.value.pan&&
        this.users[i].password==form.value.password
        ){
          k=1;
         // this.router.navigate(['/user']);
        }
      
        

if(k==1){

 // console.log(form.value.pan);
         this.pan=form.value.pan;
  
          this.router.navigate(['/create',this.pan ]);
}
else{
 this.msg="bad credentials"
}
    }
  }
}
//this.submitted = true;

  
  
  





