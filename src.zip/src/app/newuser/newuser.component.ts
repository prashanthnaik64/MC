import { Component, OnInit } from '@angular/core';
import { User } from '../model/user';
import { Router } from '@angular/router';
import { UserserviceService } from '../userservice.service';
import { UserModel } from 'src/entity/UserModel';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-newuser',
  templateUrl: './newuser.component.html',
  styleUrls: ['./newuser.component.css']
})
export class NewuserComponent implements OnInit {
  user1:UserModel[];
  msg="";
  myForm1: FormGroup;

  constructor(private router:Router,private service:UserserviceService,private formBuilder: FormBuilder) { }

  ngOnInit() {
    {
    
      this.myForm1=this.formBuilder.group({
        name:new FormControl('',Validators.required),
        password:new FormControl('',Validators.required),
        email: new FormControl(''),
        contactNumber:new FormControl(''),
        dob:new FormControl(''),
        pan:new FormControl('')
      }
      );
    
  }
  }
  onSubmit2(form:FormGroup){
    
    let user1:UserModel={
     
      pan:form.value.pan,
      password:form.value.password,
      name:form.value.name,
      contactNumber:form.value.contactNumber,
      email:form.value.email,
      dob:form.value.dob
    }
    this.service.saveUser(user1).subscribe(data => {
      console.log(data.body);
      this.router.navigate(['/']);
    },
    error=>{
      console.log("error");
      this.msg="pan already exist";


    }


  );
  if (this.myForm1.invalid) {
    return;
  }
   
}
  
  

}
