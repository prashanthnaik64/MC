import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserserviceService } from '../userservice.service';

@Component({
  selector: 'app-userlanding',
  templateUrl: './userlanding.component.html',
  styleUrls: ['./userlanding.component.css']
})
export class UserlandingComponent implements OnInit {
  registerForm: FormGroup;
  
  submitted = false;
 

  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,private service:UserserviceService){}
   

    ngOnInit() {
      this.registerForm = this.formBuilder.group({
        pan: ['', Validators.required], 
        accountNum: ['', Validators.required],
          bankName: ['', Validators.required],
          ifsccode: ['', Validators.required],
          micrcode: ['', [Validators.required, Validators.minLength(6)]]
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  onSubmit() {
    this.submitted = true;
    this.service.saveAccounts(this.registerForm.value).subscribe(data => {
      console.log(data.body);
      this.router.navigate(['/']);
    },
    error=>{
      console.log("error");
      //this.msg="pan already exist";


    }


  );
  }

}
