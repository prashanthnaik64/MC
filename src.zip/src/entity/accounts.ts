export interface Accounts{
    bankId?:number;
    pan:string;
    accountNum:number;
    bankName:string;
    ifsccode:string;
    micrcode:string;
    
}