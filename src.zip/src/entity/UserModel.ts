export interface UserModel{
    pan?:string;
    contactNumber:string;
    email:string;
    name:string;
    dob:string;
    password:string;
}